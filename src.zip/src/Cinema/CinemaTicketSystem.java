package Cinema;

import java.util.Scanner;

public class CinemaTicketSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to the Cinema Ticket System");
        System.out.println("Please select a movie to watch");
        System.out.println("1 - Paper Towns");
        System.out.println("2 - Money Heist");
        System.out.println("3 - Matrix");

        int movieChoice = sc.nextInt();

        if (movieChoice < 1 || movieChoice > 3) {
            System.out.println("Invalid choice. Please select a movie from 1 to 3.");
            return;
        }

        Movie[] movies = {
                new Movie("The Dark Knight"),
                new Movie("Inception"),
                new Movie("Matrix")
        };

        Movie movie = movies[movieChoice - 1];

        System.out.println("You have selected " + movie.getMovieName() + ".");

        System.out.println("Please select a ticket type.");
        System.out.println("1 - Adult");
        System.out.println("2 - Child");
        System.out.println("3 - Student");
        System.out.println("4 - Family");

        int ticketTypeChoice = sc.nextInt();

        Ticket ticket = new Ticket(ticketTypeChoice);

        System.out.println("Ticket type chosen: " + ticket.getTicketType());
        System.out.println("Price: $" + ticket.getTicketPrice());
        System.out.println("Thank you for choosing " + ticket.getTicketType() + " Ticket. Have a great event!");
    }
}
